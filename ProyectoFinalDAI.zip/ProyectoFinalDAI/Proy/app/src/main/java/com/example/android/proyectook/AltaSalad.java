package com.example.android.proyectook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class AltaSalad extends AppCompatActivity {

    private Spinner top1, top2, veg1, veg2;
    private Button registrar;
    private TextView orden, fecha;
    public int usuario;

    //En está actividad se registra la orden de una ensalada con sus respectivos toppings.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alta_salad);

        Bundle b = this.getIntent().getExtras();
        usuario = Integer.parseInt(b.get("usuario").toString());

        registrar = (Button)findViewById(R.id.btnAltaSalad);
        top1 = (Spinner)findViewById(R.id.spinner1);
        top2 = (Spinner)findViewById(R.id.spinner2);
        veg1 = (Spinner)findViewById(R.id.spinner3);
        veg2 = (Spinner)findViewById(R.id.spinner4);
        orden = (TextView)findViewById(R.id.txNoOrden);
        fecha = (TextView)findViewById(R.id.txtFecha);

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String topp1 = top1.getSelectedItem().toString();
                String topp2 = top2.getSelectedItem().toString();
                String vegg1 = veg1.getSelectedItem().toString();
                String vegg2 = veg2.getSelectedItem().toString();
                int ord = Integer.parseInt(orden.getText().toString());
                String fech = fecha.getText().toString();

                InterfazBD i = new InterfazBD(v.getContext());
                i.altaEnsalada(ord, topp1, topp2, vegg1, vegg2, usuario, fech);

                Toast.makeText(v.getContext(), "Alta exitosa", Toast.LENGTH_SHORT).show();
            }
        });

    }


}
