package com.example.android.proyectook;

import android.content.ContentValues;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AltaTupper extends AppCompatActivity {

    private EditText txIdTupper, txDescrip;
    private Button altaTupper, modificar;
    public int usuario;

    //En está actividad el usuario registra su tupper y tiene también la opción de modificar la descripción de su tupper, en caso de querer cambiarlo.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alta_tupper);

        txIdTupper = (EditText)findViewById(R.id.txIdTupper);
        txDescrip = (EditText)findViewById(R.id.txDescrip);
        altaTupper = (Button)findViewById(R.id.btAltaTupper);
        modificar = (Button)findViewById(R.id.btModificar);

        Bundle b = this.getIntent().getExtras();
        usuario = Integer.parseInt(b.get("usuario").toString());

        altaTupper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int idTup = Integer.parseInt(txIdTupper.getText().toString());
                String desc = txDescrip.getText().toString();
                InterfazBD i = new InterfazBD(v.getContext());
                i.registroTupper(idTup, desc, usuario);
                Toast.makeText(v.getContext(), "Alta de Tupper exitosa", Toast.LENGTH_SHORT).show();
            }
        });

        modificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nuevaDescrip = txDescrip.getText().toString();
                int idTup = Integer.parseInt(txIdTupper.getText().toString());
                InterfazBD i = new InterfazBD(v.getContext());
                i.modificarDescrip(idTup, nuevaDescrip);
                Toast.makeText(v.getContext(), "Modificación de Tupper exitosa", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
