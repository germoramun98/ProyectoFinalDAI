package com.example.android.proyectook;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by dai on 07/12/2017.
 */

//Está es la clase necesaria para la creación de la base datos con sus respectivas tablas
public class ConexionBD extends SQLiteOpenHelper {

    //Script de creación de tablas
    String cadena1="create table if not exists Persona (cu integer primary key, nombre text, apellido text, pwd text, correo text, carrera text)";
    String cadena2="create table if not exists Tupper (idTupper integer primary key, descripcion text, cu integer)";
    String cadena3="create table if not exists Ensalada (noOrden integer primary key, fecha text, cu integer)";
    String cadena4="create table if not exists Topping (noOrden integer, topping text)";


    public ConexionBD (Context context){
        super (context, "base.db", null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(cadena1);
        db.execSQL(cadena2);
        db.execSQL(cadena3);
        db.execSQL(cadena4);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }
}
