package com.example.android.proyectook;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class ConsultaInfo extends AppCompatActivity {

    int usuario;
    private EditText cu, nombre, ape, correo, pwd, descrip;
    //En está actividad, el usuario puede ver su información personal

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta_info);

        Bundle b = this.getIntent().getExtras();
        usuario=Integer.parseInt(b.get("usuario").toString());

        cu = (EditText) findViewById(R.id.txCu);
        nombre = (EditText) findViewById(R.id.txNombre);
        ape = (EditText) findViewById(R.id.txApellido);
        correo = (EditText) findViewById(R.id.txCorreo);
        pwd = (EditText) findViewById(R.id.txtPwd);
        descrip = (EditText) findViewById(R.id.txDescrip);


        InterfazBD i = new InterfazBD(this);
        List<String> li = i.consultaTodo(usuario);

        if(!li.isEmpty()){
            cu.setText(li.get(0));
            nombre.setText(li.get(1));
            ape.setText(li.get(2));
            pwd.setText(li.get(3));
            correo.setText(li.get(4));
            descrip.setText(li.get(6));
        }


    }


}
