package com.example.android.proyectook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Help extends AppCompatActivity {

    private int usuario;
    //En está actividad el usuario puede acceder a un teléfono de atención a clientes, así como darse de baja de la aplicación. Cuando un usuario se da de baja, tanto su perfil como su tupper y sus pedidos anteriores se eliminan de la base de datos.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);


        Bundle b = this.getIntent().getExtras();
        usuario=Integer.parseInt(b.get("usuario").toString());
    }

    public void eliminaUsuario (View v){
        InterfazBD i = new InterfazBD(v.getContext());
        i.eliminaUsuario(usuario);
        Toast.makeText(v.getContext(), "Has sido dado de BAJA", Toast.LENGTH_SHORT);

        Intent intent = new Intent(Help.this, MainActivity.class);
        startActivity(intent);
    }
}
