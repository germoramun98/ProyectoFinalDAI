package com.example.android.proyectook;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import com.example.android.proyectook.ConexionBD;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by android on 18/12/2017.
 */

public class InterfazBD {

    ConexionBD con;
    SQLiteDatabase db;

    //Instanciar la Conexion de la base de datos
    public InterfazBD(Context c) {
        con = new ConexionBD(c);

    }

    //Abrir la conexion a la base de datos
    public void open() throws SQLException {
        db = con.getWritableDatabase();
    }

    //Cerrar la conexión a la base de datos
    public void close() throws SQLException {
        con.close();
    }

    //Método para validar la sesión de un usuario
    public int validarSesion(int cu, String pwd) {
        open();
        String query = "select pwd from Persona where cu=" + cu + ";";
        Cursor c = db.rawQuery(query, null);
        if(c !=  null) {
            if (c.moveToNext()) {
                String res = c.getString(0);
                if (pwd.equals(res)) {
                    c.close();
                    close();
                    return 1;
                }
            }
        }

        c.close();
        close();
        return -1;
    }
    //Método para registrar al cliente
    public long registro(String nombre, String apellido, int cu, String carrera, String correo, String pwd) {
        ContentValues valores;
        open();
        valores = new ContentValues();
        valores.put("cu", cu);
        valores.put("nombre", nombre);
        valores.put("apellido", apellido);
        valores.put("pwd", pwd);
        valores.put("correo", correo);
        valores.put("carrera", carrera);
        long clave = db.insert("Persona", null, valores);
        close();

        return clave;
    }
    //Método para pedir una ensalada con sus respectivos toppings
    public void altaEnsalada(int orden, String topping1, String topping2, String vegetal1, String vegetal2, int cu, String fecha) {
        ContentValues valores;
        open();
        valores = new ContentValues();

        valores.put("noOrden", orden);
        valores.put("fecha", fecha);
        valores.put("cu", cu);
        db.insert("Ensalada", null, valores);
        close();

        ContentValues valores2;
        open();
        valores2 = new ContentValues();

        valores2.put("noOrden", orden);
        valores2.put("topping", topping1);
        valores2.put("noOrden", orden);
        valores2.put("topping", topping2);
        valores2.put("noOrden", orden);
        valores2.put("topping", vegetal1);
        valores2.put("noOrden", orden);
        valores2.put("topping", vegetal2);
        db.insert("Topping", null, valores2);
        close();
    }
    //Método para dar de alta el tupper de un usuario
    public void registroTupper(int idTupper, String descrip, int cu) {
        ContentValues valores;
        open();
        valores = new ContentValues();
        valores.put("idTupper", idTupper);
        valores.put("descripcion", descrip);
        valores.put("cu", cu);
        db.insert("Tupper", null, valores);
        close();
    }
    //Método para modificar la descripción del tupper de un usuario
    public void modificarDescrip(int idTupper, String descrip) {
        ContentValues valores;
        open();
        valores = new ContentValues();
        valores.put("descripcion", descrip);
        db.update("Tupper", valores, "idTupper =" + idTupper, null);
        close();
    }
    //Método para darse de baja de la aplicación
    public void eliminaUsuario(int cu) {
        open();
        db.execSQL("delete from Persona where cu=" + cu + ";");
        db.execSQL("delete from Tupper where cu=" + cu + ";");
        db.execSQL("delete from Ensalada where cu=" + cu + ";");
        close();
    }
    //Método para generar un reporte de las ensaladas pedidas
    public List<String> generaReporte(int cu) {
        List<String> li = new ArrayList<>();

        try {
            open();
            Cursor cr = db.rawQuery("select noOrden, fecha from Ensalada where cu = " + cu + "", null);
            if (cr != null) {
                if (cr.moveToFirst()) {
                    do {
                        int no = cr.getInt(cr.getColumnIndex("noOrden"));
                        String fecha = cr.getString(cr.getColumnIndex("fecha"));

                        li.add("" + no);
                        li.add(fecha);
                    } while (cr.moveToNext());
                }
            }
            cr.close();
            close();
        } catch (Exception e) {
            return null;
        }
        return li;
    }
    //Método que trae la información del usuario y su Tupper.
    public List<String>  consultaTodo(int cu){
        List<String> li = new ArrayList<>();

        open();
        String query = "select * from Persona where cu=" + cu + ";";
        Cursor c = db.rawQuery(query, null);
        if(c !=  null) {
            if (c.moveToFirst()) {
                do{
                    int cU = c.getInt(c.getColumnIndex("cu"));
                    String strCu = ""+cU;
                    String nombre = c.getString(c.getColumnIndex("nombre"));
                    String apellido = c.getString(c.getColumnIndex("apellido"));
                    String pwd = c.getString(c.getColumnIndex("pwd"));
                    String correo = c.getString(c.getColumnIndex("correo"));
                    String carrera = c.getString(c.getColumnIndex("carrera"));

                    li.add(strCu);
                    li.add(nombre);
                    li.add(apellido);
                    li.add(pwd);
                    li.add(correo);
                    li.add(carrera);

                } while(c.moveToNext());
            }
        }
        c.close();

        String query2 = "select descripcion from Tupper where cu = "+cu+";";
        Cursor c2 = db.rawQuery(query2, null);
        if(c2 !=  null) {
            if (c2.moveToNext()) {
                String descrip = c2.getString(c2.getColumnIndex("descripcion"));

                li.add(descrip);
            }
        }

        c2.close();
        close();

        return li;
    }
}
