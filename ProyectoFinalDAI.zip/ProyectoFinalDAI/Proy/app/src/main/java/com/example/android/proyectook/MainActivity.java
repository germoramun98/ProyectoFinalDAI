package com.example.android.proyectook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button registro, iniSesion;
    private EditText usu, pwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registro = (Button)findViewById(R.id.regis);
        iniSesion = (Button)findViewById(R.id.iniSession);
        usu = (EditText)findViewById(R.id.txtUsu);
        pwd = (EditText)findViewById(R.id.txtPsw);

    }

    public void iniSesion (View v){
        String strCu = usu.getText().toString();
        String contra = pwd.getText().toString();

        InterfazBD i = new InterfazBD(v.getContext());

        if (!strCu.equals("") && !contra.equals("")) {
            int cu = Integer.parseInt(strCu);
            int res = i.validarSesion(cu, contra);

            if (res > 0) {
                Intent intent = new Intent(MainActivity.this, Menu.class);

                Bundle b = new Bundle();
                b.putString("usuario", "" + cu);
                intent.putExtras(b);
                startActivity(intent);
            }
        }else {
            Toast.makeText(v.getContext(), "EL usuario o contra es incorrecto", Toast.LENGTH_LONG).show();
        }
    }
//Está es la actividad inicial en donde un usuario decide iniciar sesión o registrarse
    public void registro (View w){
        Intent intent = new Intent(MainActivity.this, Registro.class);

        Bundle b = new Bundle();
        b.putString("usuario", usu.getText().toString());
        b.putString("password", pwd.getText().toString());
        intent.putExtras(b);
        startActivity(intent);
    }
}
