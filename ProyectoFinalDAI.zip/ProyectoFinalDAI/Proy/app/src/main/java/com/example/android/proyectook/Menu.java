package com.example.android.proyectook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Menu extends AppCompatActivity {

    private String usuario;
    private TextView saludo;
    private Button altaEnsalada, pedidos;
    //Está es la actividad en donde el usuario decide qué actividad realizar. Puede: ordenar una ensalada, ver sus pedidos anteriores, dar de alta un tupper, revisar su perfil, o accede al menú de ayuda. La funcionalidad de “modificar descripción del tupper” se encuentra en la opción Tupper. La funcionalidad de “dar de baja usuario” se encuentra en el botón de ayuda.


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        saludo = (TextView)findViewById(R.id.saludo) ;
        altaEnsalada = (Button)findViewById(R.id.btnAltaSalad);
        pedidos = (Button)findViewById(R.id.pedidos);

        Bundle b = this.getIntent().getExtras();
        usuario = b.get("usuario").toString();
        saludo.setText("Hola: " + usuario);

    }

    public void regisEnsalada (View v){
        Intent intent = new Intent(Menu.this, AltaSalad.class);

        Bundle b = new Bundle();
        b.putString("usuario", usuario);
        intent.putExtras(b);
        startActivity(intent);
    }

    public void generaReporte (View w){
        Intent intent = new Intent(Menu.this, MuestraPedidos.class);

        Bundle b = new Bundle();
        b.putString("usuario", usuario);
        intent.putExtras(b);
        startActivity(intent);
    }

    public void cierraSesion(View w){
        Intent intent = new Intent(Menu.this, MainActivity.class);

        Bundle b = new Bundle();
        b.putString("usuario", usuario);
        b.clear();
        startActivity(intent);
    }

    public void altaTupper (View v){
        Intent intent = new Intent(Menu.this, AltaTupper.class);

        Bundle b = new Bundle();
        b.putString("usuario", usuario);
        intent.putExtras(b);
        startActivity(intent);
    }

    public void ayuda (View w){
        Intent intent = new Intent(Menu.this, Help.class);

        Bundle b = new Bundle();
        b.putString("usuario", usuario);
        intent.putExtras(b);
        startActivity(intent);
    }

    public void consultaInfo (View w){
        Intent intent = new Intent(Menu.this, ConsultaInfo.class);

        Bundle b = new Bundle();
        b.putString("usuario", usuario);
        intent.putExtras(b);
        startActivity(intent);
    }
}
