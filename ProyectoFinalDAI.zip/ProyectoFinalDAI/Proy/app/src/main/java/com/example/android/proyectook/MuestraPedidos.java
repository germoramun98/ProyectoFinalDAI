package com.example.android.proyectook;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MuestraPedidos extends AppCompatActivity {

    String usuario;

    //En está actividad el usuario puede ver los pedidos que ha realizado previamente

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muestra_pedidos);

        Bundle b = this.getIntent().getExtras();
        usuario = b.get("usuario").toString();

        GridView gvEnsaladas = (GridView) findViewById(R.id.gvEnsaladas);

        InterfazBD i = new InterfazBD(this);
        List<String> li = i.generaReporte(Integer.parseInt(usuario));

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, li);
        gvEnsaladas.setAdapter(dataAdapter);
    }
}
