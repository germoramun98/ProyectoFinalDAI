package com.example.android.proyectook;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.android.proyectook.InterfazBD;
import com.example.android.proyectook.R;

public class Registro extends AppCompatActivity {

    private EditText nombre, apellido, correo, claveUn, contra;
    private Spinner carrera;
    private Button registrar;

    //Está es la actividad necesaria para poder registrar a un nuevo usuario.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        nombre = (EditText) findViewById(R.id.txNombre);
        apellido = (EditText) findViewById(R.id.txApellido);
        correo = (EditText) findViewById(R.id.txCorreo);
        claveUn = (EditText) findViewById(R.id.txCu);
        contra = (EditText) findViewById(R.id.txtPwd);
        carrera = (Spinner) findViewById(R.id.cbCarrera);
        registrar = (Button) findViewById(R.id.registrar);

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nom = nombre.getText().toString();
                String ape = apellido.getText().toString();
                String cor = correo.getText().toString();
                int cu = Integer.parseInt(claveUn.getText().toString());
                String pwd = contra.getText().toString();
                String car = carrera.getSelectedItem().toString();

                InterfazBD iBD = new InterfazBD(v.getContext());
                long clave = iBD.registro(nom, ape, cu, car, cor, pwd);

                Toast.makeText(v.getContext(), "Alta exitosa: " + clave, Toast.LENGTH_SHORT).show();
            }
        });
    }
}

